from tests.test_algorithms import run_tests


if __name__ == "__main__":
    run_tests()